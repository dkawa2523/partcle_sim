# particle_tracer 図版一式

このZIPには、PowerPointに貼り付けるために作成した図版をまとめています。

## 01_core_diagrams
- チャンバー概念図
- 全体アーキテクチャ
- モデル切替設計
- 基本式と積分器
- COMSOL manifest-first ワークフロー
- COMSOL同精度化の難所

## 02_expert_theory_diagrams
- 抗力モデル選択マップ
- 場補間・valid mask
- 壁衝突・wall law
- プラズマなし/ありのモデル差
- charge と追加力場
- source law / 粒子初期条件
- 境界認識・壁近傍ソルバー
- 数値計算の工夫とCOMSOL同等化

## 03_decision_and_cost_diagrams
- 処理区分 × 理論モデル × 実装・診断マップ
- COMSOL faithful 比較ワークフロー
- 入力契約と検証ゲート
- 開発コストWBS
- 必要スキルと役割分担
- 既製ライブラリと独自実装の境界

注記: 図版は説明用の概念図です。実機形状やCOMSOLモデルの完全な幾何再現ではありません。
